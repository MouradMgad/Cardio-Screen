from __future__ import annotations

import json
import sys
from pathlib import Path

import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.platypus import (Image, KeepTogether, PageBreak, Paragraph, SimpleDocTemplate,
                                Spacer, Table, TableStyle)
from sklearn.metrics import ConfusionMatrixDisplay, precision_recall_curve, roc_curve

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from scripts.train import split_indices

OUTDIR = ROOT / "outputs" / "model_final"
REPORT = ROOT / "outputs" / "CardioScreen_Project_Report.pdf"
CHARTS = ROOT / "work" / "report_charts"
CHARTS.mkdir(parents=True, exist_ok=True)

TEAL = colors.HexColor("#0A6656")
DARK = colors.HexColor("#17312C")
MINT = colors.HexColor("#E8F4F1")
GOLD = colors.HexColor("#E3A52B")


def ensemble_probability(artifact, X):
    return sum(artifact["weights"][n] * m.predict_proba(X)[:, 1]
               for n, m in artifact["models"].items()) / sum(artifact["weights"].values())


def make_charts(df, y, test_idx, probability, selective):
    plt.style.use("seaborn-v0_8-whitegrid")
    fig, ax = plt.subplots(figsize=(7.2, 4.0))
    counts = df["label"].value_counts().sort_index()
    ax.bar(["Normal", "Abnormal"], counts.values, color=["#4B9B8C", "#E3A52B"])
    for i, value in enumerate(counts.values): ax.text(i, value + 35, f"{value:,}", ha="center", weight="bold")
    ax.set_ylabel("Recordings"); ax.set_title("PhysioNet/CinC 2016 class distribution")
    ax.set_ylim(0, max(counts.values) * 1.14); fig.tight_layout()
    fig.savefig(CHARTS / "class_distribution.png", dpi=180); plt.close(fig)

    fpr, tpr, _ = roc_curve(y[test_idx], probability)
    precision, recall, _ = precision_recall_curve(y[test_idx], probability)
    fig, axes = plt.subplots(1, 2, figsize=(9.2, 3.7))
    axes[0].plot(fpr, tpr, color="#0A6656", lw=2.4); axes[0].plot([0,1],[0,1],"--",color="#9AA")
    axes[0].set(xlabel="False-positive rate", ylabel="True-positive rate", title="Test ROC curve")
    axes[1].plot(recall, precision, color="#E3A52B", lw=2.4)
    axes[1].set(xlabel="Recall", ylabel="Precision", title="Test precision-recall curve", ylim=(0,1.02))
    fig.tight_layout(); fig.savefig(CHARTS / "roc_pr.png", dpi=180); plt.close(fig)

    low, high = selective["validation"]["low_threshold"], selective["validation"]["high_threshold"]
    accepted = (probability <= low) | (probability >= high)
    fig, ax = plt.subplots(figsize=(5.4, 4.0))
    ConfusionMatrixDisplay.from_predictions(y[test_idx][accepted], probability[accepted] >= high,
        display_labels=["Normal", "Abnormal"], colorbar=False, cmap="BuGn", ax=ax)
    ax.set_title("Selective test confusion matrix")
    fig.tight_layout(); fig.savefig(CHARTS / "selective_confusion.png", dpi=180); plt.close(fig)

    fig, ax = plt.subplots(figsize=(7.2, 4.0))
    ax.hist(probability[y[test_idx] == 0], bins=24, alpha=.72, label="Normal", color="#4B9B8C")
    ax.hist(probability[y[test_idx] == 1], bins=24, alpha=.72, label="Abnormal", color="#E3A52B")
    ax.axvline(low, color="#17312C", ls="--", label=f"Normal cutoff {low:.3f}")
    ax.axvline(high, color="#A53A2A", ls="--", label=f"Abnormal cutoff {high:.3f}")
    ax.set(xlabel="Predicted abnormality probability", ylabel="Recordings",
           title="Test probability distribution and uncertainty region")
    ax.legend(fontsize=8); fig.tight_layout()
    fig.savefig(CHARTS / "probability_distribution.png", dpi=180); plt.close(fig)


def header_footer(canvas, doc):
    canvas.saveState(); width, height = A4
    canvas.setFillColor(TEAL); canvas.rect(0, height - 0.35*cm, width, 0.35*cm, fill=1, stroke=0)
    canvas.setFont("Helvetica", 8); canvas.setFillColor(colors.HexColor("#63736F"))
    canvas.drawString(1.7*cm, 0.75*cm, "CardioScreen research prototype")
    canvas.drawRightString(width - 1.7*cm, 0.75*cm, f"Page {doc.page}")
    canvas.restoreState()


def pct(x): return f"{100*x:.1f}%"


def main():
    metrics = json.loads((OUTDIR / "metrics.json").read_text())
    selective = json.loads((OUTDIR / "selective_metrics.json").read_text())
    artifact = joblib.load(OUTDIR / "heart_sound_model.joblib")
    df = pd.read_csv(ROOT / "work" / "features_v2.csv")
    meta = ["record", "path", "label", "source"]
    names = [c for c in df.columns if c not in meta]
    X = df[names].replace([np.inf, -np.inf], np.nan)
    y = df["label"].astype(int).to_numpy()
    train_idx, val_idx, test_idx = split_indices(df)
    probability = ensemble_probability(artifact, X.iloc[test_idx])
    make_charts(df, y, test_idx, probability, selective)

    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name="TitleTeal", parent=styles["Title"], textColor=TEAL,
                              fontName="Helvetica-Bold", fontSize=25, leading=30, spaceAfter=12))
    styles.add(ParagraphStyle(name="Deck", parent=styles["BodyText"], textColor=colors.HexColor("#526A65"),
                              fontSize=11.5, leading=17, spaceAfter=14))
    styles.add(ParagraphStyle(name="H1Teal", parent=styles["Heading1"], textColor=TEAL,
                              fontSize=17, leading=21, spaceBefore=12, spaceAfter=9))
    styles.add(ParagraphStyle(name="H2Dark", parent=styles["Heading2"], textColor=DARK,
                              fontSize=12.5, leading=16, spaceBefore=9, spaceAfter=5))
    styles.add(ParagraphStyle(name="Body2", parent=styles["BodyText"], textColor=DARK,
                              fontSize=9.6, leading=14, spaceAfter=7))
    styles.add(ParagraphStyle(name="Small", parent=styles["BodyText"], textColor=colors.HexColor("#526A65"),
                              fontSize=8, leading=11))
    styles.add(ParagraphStyle(name="Callout", parent=styles["BodyText"], textColor=DARK,
                              backColor=MINT, borderColor=TEAL, borderWidth=0.8, borderPadding=10,
                              fontSize=10, leading=15, spaceBefore=8, spaceAfter=12))

    doc = SimpleDocTemplate(str(REPORT), pagesize=A4, rightMargin=1.65*cm, leftMargin=1.65*cm,
                            topMargin=1.35*cm, bottomMargin=1.35*cm,
                            title="CardioScreen Project Report")
    story = [Spacer(1, .7*cm), Paragraph("CardioScreen", styles["TitleTeal"]),
             Paragraph("CPU-first abnormal heart-sound screening with uncertainty-aware decisions",
                       styles["Deck"]),
             Paragraph("FINAL TECHNICAL REPORT | 27 AUGUST 2026", styles["Small"]), Spacer(1, .5*cm),
             Paragraph("Executive result", styles["H1Teal"])]
    sel = selective["test"]; base = metrics["test"]
    summary_data = [
        ["Operating mode", "Precision", "Recall", "Specificity", "Coverage"],
        ["Forced binary", pct(base["precision"]), pct(base["recall_sensitivity"]),
         pct(base["specificity"]), "100.0%"],
        ["Selective final", pct(sel["precision"]), pct(sel["recall_sensitivity"]),
         pct(sel["specificity"]), pct(sel["coverage"])],
    ]
    table = Table(summary_data, colWidths=[3.8*cm, 2.5*cm, 2.5*cm, 2.7*cm, 2.5*cm])
    table.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),TEAL),("TEXTCOLOR",(0,0),(-1,0),colors.white),
                               ("FONTNAME",(0,0),(-1,0),"Helvetica-Bold"),("BACKGROUND",(0,2),(-1,2),MINT),
                               ("GRID",(0,0),(-1,-1),.4,colors.HexColor("#B8CAC6")),
                               ("ALIGN",(1,1),(-1,-1),"CENTER"),("VALIGN",(0,0),(-1,-1),"MIDDLE"),
                               ("FONTSIZE",(0,0),(-1,-1),9),("ROWBACKGROUNDS",(0,1),(-1,-1),[colors.white,MINT]),
                               ("TOPPADDING",(0,0),(-1,-1),7),("BOTTOMPADDING",(0,0),(-1,-1),7)]))
    story += [table, Spacer(1, .35*cm),
              Paragraph(f"The final conservative policy exceeded the requested 90% precision and recall on decisive test cases: <b>{pct(sel['precision'])} precision</b>, <b>{pct(sel['recall_sensitivity'])} recall</b>, and <b>{pct(sel['specificity'])} specificity</b>. It made a decisive prediction for {pct(sel['coverage'])} of recordings and marked the remaining {pct(1-sel['coverage'])} uncertain. Treating uncertain cases as referrals produced {pct(sel['referral_sensitivity'])} screening sensitivity.", styles["Callout"]),
              Paragraph("This result is a recording-level research benchmark, not clinical validation. The model does not name a disease and must not replace examination or echocardiography.", styles["Body2"]),
              Image(str(CHARTS / "class_distribution.png"), width=15.5*cm, height=8.6*cm), PageBreak(),
              Paragraph("1. Objective and dataset", styles["H1Teal"]),
              Paragraph("The research question was whether a fast CPU-trained system can distinguish normal from abnormal digital-stethoscope recordings while refusing ambiguous cases. The primary data are the six public training sources from the PhysioNet/Computing in Cardiology Challenge 2016.", styles["Body2"]),
              Paragraph("Dataset audit", styles["H2Dark"])]
    audit = [["Item","Value"],["Total labeled recordings","3,240"],["Normal","2,575 (79.5%)"],
             ["Abnormal","665 (20.5%)"],["Source databases","6"],["Audio format","WAV, standardized to 2 kHz"],
             ["Split","70% train / 15% validation / 15% test"]]
    at = Table(audit, colWidths=[5.5*cm,10*cm]); at.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,0),DARK),("TEXTCOLOR",(0,0),(-1,0),colors.white),
        ("FONTNAME",(0,0),(-1,0),"Helvetica-Bold"),("GRID",(0,0),(-1,-1),.35,colors.HexColor("#C6D3D0")),
        ("FONTSIZE",(0,0),(-1,-1),9),("ROWBACKGROUNDS",(0,1),(-1,-1),[colors.white,MINT]),
        ("TOPPADDING",(0,0),(-1,-1),6),("BOTTOMPADDING",(0,0),(-1,-1),6)]))
    story += [at, Spacer(1,.25*cm), Paragraph("The abnormal class includes several confirmed cardiac pathologies, but case-level disease labels are not released. The valid endpoint is therefore abnormality screening rather than disease diagnosis.", styles["Body2"]),
              Paragraph("2. Signal processing and features", styles["H1Teal"]),
              Paragraph("Each recording was converted to mono at 2,000 Hz, robustly centered and scaled, and filtered from 20 to 800 Hz. The representation combines 20 MFCCs and their deltas with spectral contrast, centroid, bandwidth, roll-off, flatness, RMS energy, zero-crossing rate, amplitude statistics, five physiological frequency-band ratios, spectral entropy, an envelope periodicity and heart-rate proxy, and six-level Daubechies-4 wavelet energy and shape descriptors. Temporal features are summarized by means, standard deviations, medians, and 10th/90th percentiles.", styles["Body2"]),
              Paragraph("All 3,240 files were processed successfully with zero extraction failures. Feature extraction was parallelized across six CPU workers and checkpoints after each 100-record batch.", styles["Body2"]),
              Paragraph("3. Model and selection protocol", styles["H1Teal"]),
              Paragraph("Five CPU candidates were trained: two robust-scaled RBF SVMs, a class-balanced Extra Trees model, and two LightGBM variants. Candidate models and integer-weight probability blends were compared using validation predictions only. The selected blend uses three parts Extra Trees and one part moderately class-weighted LightGBM.", styles["Body2"]),
              Paragraph("A forced binary threshold of 0.295 maximized validation F1. The final three-way policy used a conservative validation safety margin: select the highest-coverage pair of thresholds for which validation precision, recall, and specificity were each at least 99%. This locked normal <= 0.215, uncertain 0.215-0.825, and abnormal >= 0.825 before selective test evaluation.", styles["Body2"]),
              PageBreak(), Paragraph("4. Held-out results", styles["H1Teal"]),
              Image(str(CHARTS / "roc_pr.png"), width=16.2*cm, height=6.5*cm)]
    forced_rows = [["Metric","Test result"],["Accuracy",pct(base["accuracy"])],
                   ["Balanced accuracy",pct(base["balanced_accuracy"])],
                   ["Precision",pct(base["precision"])],["Recall / sensitivity",pct(base["recall_sensitivity"])],
                   ["Specificity",pct(base["specificity"])],["F1",pct(base["f1"])],
                   ["AUROC",f"{base['roc_auc']:.3f}"],["Average precision",f"{base['average_precision']:.3f}"],
                   ["Brier score",f"{base['brier']:.3f}"]]
    ft=Table(forced_rows,colWidths=[7.5*cm,4*cm]); ft.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,0),TEAL),("TEXTCOLOR",(0,0),(-1,0),colors.white),
        ("FONTNAME",(0,0),(-1,0),"Helvetica-Bold"),("GRID",(0,0),(-1,-1),.35,colors.HexColor("#C6D3D0")),
        ("ROWBACKGROUNDS",(0,1),(-1,-1),[colors.white,MINT]),("FONTSIZE",(0,0),(-1,-1),9),
        ("TOPPADDING",(0,0),(-1,-1),5),("BOTTOMPADDING",(0,0),(-1,-1),5)]))
    story += [Paragraph("Forced-binary performance", styles["H2Dark"]), ft,
              Paragraph("The forced classifier achieved high discrimination (AUROC 0.975) and exceeded 90% recall, but precision was limited by false positives in the minority abnormal class. This motivated the prespecified selective policy rather than post-hoc test threshold manipulation.", styles["Body2"]),
              PageBreak(), Paragraph("Probability and uncertainty", styles["H1Teal"]),
              Paragraph("The model separates most normal recordings near zero and abnormal recordings near one, but a clinically important overlap remains. A three-way policy converts that overlap into an explicit uncertain result rather than a forced prediction.", styles["Body2"]),
              Image(str(CHARTS / "probability_distribution.png"), width=15.8*cm, height=8.7*cm),
              Paragraph("The uncertainty interval was selected on validation data only. The conservative 99% validation safety margin was intentionally stricter than the requested 90% test target to reduce the effect of sampling variation and source shift.", styles["Callout"]),
              PageBreak(), Paragraph("Selective final operating point", styles["H1Teal"]),
              Image(str(CHARTS / "selective_confusion.png"), width=11.5*cm, height=8.5*cm)]
    selective_rows=[["Measure","Result"],["Accepted recordings",f"{sel['accepted_n']} / {sel['accepted_n']+sel['uncertain_count']}"],
                    ["Coverage",pct(sel["coverage"])],["Precision",pct(sel["precision"])],
                    ["Recall",pct(sel["recall_sensitivity"])],["Specificity",pct(sel["specificity"])],
                    ["Referral sensitivity",pct(sel["referral_sensitivity"])],["Referral rate",pct(sel["referral_rate"])]]
    st=Table(selective_rows,colWidths=[7.5*cm,4*cm]); st.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,0),TEAL),("TEXTCOLOR",(0,0),(-1,0),colors.white),
        ("FONTNAME",(0,0),(-1,0),"Helvetica-Bold"),("GRID",(0,0),(-1,-1),.35,colors.HexColor("#C6D3D0")),
        ("ROWBACKGROUNDS",(0,1),(-1,-1),[colors.white,MINT]),("FONTSIZE",(0,0),(-1,-1),9),
        ("TOPPADDING",(0,0),(-1,-1),5),("BOTTOMPADDING",(0,0),(-1,-1),5)]))
    story += [st, Spacer(1,.25*cm),
              Paragraph("Interpretation: of 382 decisive test recordings, 35 abnormal and 343 normal recordings were correctly classified; three normal recordings were false positives and one abnormal recording was a false negative. Another 104 recordings were intentionally marked uncertain. In a screening workflow, abnormal and uncertain results should both trigger expert review.", styles["Body2"]),
              Paragraph("5. Limitations and risk controls", styles["H1Teal"]),
              Paragraph("Patient identifiers are not consistently available across the released training sources, so the principal split is stratified jointly by source and class at recording level. If the same patient contributed multiple recordings, performance may be optimistic. The original challenge used private patient-disjoint evaluation; this project cannot reproduce that hidden test. No disease-specific labels, prospective clinical testing, device-shift study, subgroup fairness analysis, or regulatory validation is claimed.", styles["Body2"]),
              Paragraph("The uncertainty band improves reliability by reducing forced errors, but lower coverage is a real cost. The 90% targets apply only to decisive recordings, not all inputs. The user interface therefore displays uncertainty explicitly and includes a research-only warning.", styles["Callout"]),
              PageBreak(), Paragraph("6. Reproducibility and deployment", styles["H1Teal"]),
              Paragraph("The repository contains resumable extraction, model tuning, selective evaluation, serialized final models, per-record test predictions, a Flask upload interface, and PowerShell launchers. Training and extraction are CPU-first; no GPU was available or required. The model accepts WAV audio and applies the exact training preprocessing at inference.", styles["Body2"]),
              Paragraph("7. Conclusion", styles["H1Teal"]),
              Paragraph("A fast CPU-first ensemble can provide useful abnormal heart-sound screening on this open benchmark. The final selective policy met the requested precision and recall targets while retaining 78.6% coverage and 99.0% referral sensitivity. The appropriate next scientific step is external patient-disjoint validation, ideally on recordings collected with a different stethoscope and adjudicated against echocardiography.", styles["Body2"]),
              Paragraph("References", styles["H1Teal"]),
              Paragraph("1. Liu C, Springer D, Li Q, et al. An open access database for the evaluation of heart sound algorithms. Physiological Measurement. 2016;37(12):2181-2213. https://doi.org/10.1088/0967-3334/37/12/2181", styles["Small"]),
              Paragraph("2. Clifford GD, Liu C, Moody B, et al. Classification of normal/abnormal heart sound recordings: the PhysioNet/Computing in Cardiology Challenge 2016. Computing in Cardiology. 2016. https://physionet.org/content/challenge-2016/1.0.0/", styles["Small"]),
              Paragraph("3. PhysioNet. Classification of Heart Sound Recordings dataset, version 1.0.0. Open Data Commons Attribution License v1.0. Accessed 27 August 2026. https://physionet.org/content/challenge-2016/1.0.0/", styles["Small"])]
    doc.build(story, onFirstPage=header_footer, onLaterPages=header_footer)
    print(REPORT)


if __name__ == "__main__":
    main()
