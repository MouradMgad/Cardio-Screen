from __future__ import annotations

import json
import sys
from pathlib import Path

import joblib
import librosa
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.platypus import Image, PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle
from sklearn.metrics import ConfusionMatrixDisplay, precision_recall_curve, roc_curve

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from scripts.train import split_indices
from heart_sound.features import bandpass, load_audio

MODEL_DIR = ROOT / "outputs" / "model_final"
REPORT = ROOT / "outputs" / "CardioScreen_Project_Report.pdf"
CHARTS = ROOT / "work" / "report_charts_bee"
CHARTS.mkdir(parents=True, exist_ok=True)

BLACK = colors.HexColor("#171717")
YELLOW = colors.HexColor("#F4C430")
PALE = colors.HexColor("#FFF6CF")
GRAY = colors.HexColor("#5C5C5C")
WHITE = colors.white


def probability(artifact, frame):
    weighted = sum(artifact["weights"][name] * model.predict_proba(frame)[:, 1]
                   for name, model in artifact["models"].items())
    return weighted / sum(artifact["weights"].values())


def make_charts(df, y_test, probabilities, selective, predictions):
    plt.style.use("seaborn-v0_8-whitegrid")
    fig, ax = plt.subplots(figsize=(7.2, 3.7))
    counts = df["label"].value_counts().sort_index()
    ax.bar(["Normal", "Abnormal"], counts.values, color=["#171717", "#F4C430"])
    for i, value in enumerate(counts.values):
        ax.text(i, value + 35, f"{value:,}", ha="center", weight="bold")
    ax.set_ylabel("Number of recordings")
    ax.set_title("Dataset class distribution")
    ax.set_ylim(0, max(counts.values) * 1.14)
    fig.tight_layout()
    fig.savefig(CHARTS / "class_distribution.png", dpi=180)
    plt.close(fig)

    fpr, tpr, _ = roc_curve(y_test, probabilities)
    precision, recall, _ = precision_recall_curve(y_test, probabilities)
    fig, axes = plt.subplots(1, 2, figsize=(9.4, 3.6))
    axes[0].plot(fpr, tpr, color="#171717", lw=2.4)
    axes[0].plot([0, 1], [0, 1], "--", color="#A0A0A0")
    axes[0].set(xlabel="False-positive rate", ylabel="True-positive rate", title="ROC curve")
    axes[1].plot(recall, precision, color="#E0AA00", lw=2.4)
    axes[1].set(xlabel="Recall", ylabel="Precision", title="Precision-recall curve", ylim=(0, 1.02))
    fig.tight_layout()
    fig.savefig(CHARTS / "roc_pr.png", dpi=180)
    plt.close(fig)

    low = selective["validation"]["low_threshold"]
    high = selective["validation"]["high_threshold"]
    accepted = (probabilities <= low) | (probabilities >= high)
    fig, ax = plt.subplots(figsize=(5.2, 3.9))
    ConfusionMatrixDisplay.from_predictions(
        y_test[accepted], probabilities[accepted] >= high,
        display_labels=["Normal", "Abnormal"], colorbar=False, cmap="YlOrBr", ax=ax
    )
    ax.set_title("Final test confusion matrix")
    fig.tight_layout()
    fig.savefig(CHARTS / "confusion.png", dpi=180)
    plt.close(fig)

    examples = predictions.set_index("record").loc[["e01432", "e01623"]]
    fig, axes = plt.subplots(2, 2, figsize=(9.6, 5.6))
    for row_index, (record, row) in enumerate(examples.iterrows()):
        audio, sr = load_audio(row["path"])
        shown = audio[:5 * sr]
        times = np.arange(len(shown)) / sr
        axes[row_index, 0].plot(times, shown, color="#171717" if row_index == 0 else "#D8A500", lw=0.65)
        label = "Normal" if not bool(row["label"]) else "Abnormal"
        axes[row_index, 0].set(title=f"Record {record} - reference: {label}",
                               xlabel="Time (seconds)", ylabel="Amplitude", xlim=(0, 5))
        filtered = bandpass(audio, sr)[:5 * sr]
        mel = librosa.feature.melspectrogram(y=filtered, sr=sr, n_fft=256, hop_length=64,
                                             n_mels=48, fmin=20, fmax=800)
        db = librosa.power_to_db(mel, ref=np.max)
        image = axes[row_index, 1].imshow(db, origin="lower", aspect="auto", cmap="inferno",
                                         extent=[0, 5, 20, 800])
        axes[row_index, 1].set(title="Log-mel spectrogram", xlabel="Time (seconds)",
                               ylabel="Frequency (Hz)")
    fig.tight_layout()
    fig.savefig(CHARTS / "recording_examples.png", dpi=180)
    plt.close(fig)

    detection_records = predictions.set_index("record").loc[["e01432", "a0287", "e01623"]]
    fig, ax = plt.subplots(figsize=(9.4, 3.0))
    ax.axvspan(0, 0.215, color="#D9D9D9", alpha=0.9)
    ax.axvspan(0.215, 0.825, color="#FFF2B3", alpha=0.95)
    ax.axvspan(0.825, 1.0, color="#F4C430", alpha=0.95)
    positions = [2, 1, 0]
    colors_list = ["#171717", "#A87C00", "#D39E00"]
    for position, color, (record, row) in zip(positions, colors_list, detection_records.iterrows()):
        p = float(row["probability_abnormal"])
        ax.scatter([p], [position], s=100, color=color, edgecolor="white", linewidth=1.2, zorder=3)
        ax.text(p, position + 0.18, f"{record}: {p:.3f}", ha="center", fontsize=9, weight="bold")
    ax.axvline(0.215, color="#444444", ls="--", lw=1.2)
    ax.axvline(0.825, color="#8A6500", ls="--", lw=1.2)
    ax.text(0.105, 2.55, "Likely normal", ha="center", weight="bold")
    ax.text(0.52, 2.55, "Uncertain", ha="center", weight="bold")
    ax.text(0.91, 2.55, "Abnormal", ha="center", weight="bold")
    ax.set(xlim=(0, 1), ylim=(-0.45, 2.8), xlabel="Predicted probability of an abnormal recording")
    ax.set_yticks(positions, ["Normal example", "Uncertain example", "Abnormal example"])
    ax.grid(axis="x", alpha=0.35); ax.grid(axis="y", visible=False)
    fig.tight_layout()
    fig.savefig(CHARTS / "detection_examples.png", dpi=180)
    plt.close(fig)


def page_decoration(canvas, doc):
    canvas.saveState()
    width, height = A4
    canvas.setFillColor(BLACK)
    canvas.rect(0, height - 0.42 * cm, width, 0.42 * cm, fill=1, stroke=0)
    canvas.setFillColor(YELLOW)
    canvas.rect(0, height - 0.50 * cm, width, 0.08 * cm, fill=1, stroke=0)
    canvas.setFont("Helvetica", 8)
    canvas.setFillColor(GRAY)
    canvas.drawString(1.7 * cm, 0.72 * cm, "Heart Sound Classification Project")
    canvas.drawRightString(width - 1.7 * cm, 0.72 * cm, f"Page {doc.page}")
    canvas.restoreState()


def metric_table(rows, widths):
    table = Table(rows, colWidths=widths)
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), BLACK),
        ("TEXTCOLOR", (0, 0), (-1, 0), YELLOW),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [WHITE, PALE]),
        ("GRID", (0, 0), (-1, -1), 0.45, colors.HexColor("#B8A45A")),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ]))
    return table


def pct(value):
    return f"{100 * value:.1f}%"


def main():
    model_metrics = json.loads((MODEL_DIR / "metrics.json").read_text())
    selective = json.loads((MODEL_DIR / "selective_metrics.json").read_text())
    artifact = joblib.load(MODEL_DIR / "heart_sound_model.joblib")
    df = pd.read_csv(ROOT / "work" / "features_v2.csv")
    metadata = ["record", "path", "label", "source"]
    feature_names = [column for column in df.columns if column not in metadata]
    X = df[feature_names].replace([np.inf, -np.inf], np.nan)
    y = df["label"].astype(int).to_numpy()
    _, _, test_idx = split_indices(df)
    test_probability = probability(artifact, X.iloc[test_idx])
    predictions = pd.read_csv(MODEL_DIR / "test_predictions.csv")
    make_charts(df, y[test_idx], test_probability, selective, predictions)

    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name="BeeTitle", parent=styles["Title"], textColor=BLACK,
                              fontName="Helvetica-Bold", fontSize=24, leading=29, spaceAfter=10))
    styles.add(ParagraphStyle(name="BeeSubtitle", parent=styles["BodyText"], textColor=GRAY,
                              fontSize=11.5, leading=16, spaceAfter=7))
    styles.add(ParagraphStyle(name="BeeName", parent=styles["BodyText"], textColor=BLACK,
                              fontName="Helvetica-Bold", fontSize=12, leading=16, spaceAfter=5))
    styles.add(ParagraphStyle(name="BeeH1", parent=styles["Heading1"], textColor=BLACK,
                              backColor=YELLOW, borderPadding=7, fontSize=16, leading=20,
                              spaceBefore=10, spaceAfter=9))
    styles.add(ParagraphStyle(name="BeeH2", parent=styles["Heading2"], textColor=BLACK,
                              fontSize=12.5, leading=16, spaceBefore=8, spaceAfter=5))
    styles.add(ParagraphStyle(name="BeeBody", parent=styles["BodyText"], textColor=BLACK,
                              fontSize=9.7, leading=14, spaceAfter=7))
    styles.add(ParagraphStyle(name="BeeNote", parent=styles["BodyText"], textColor=BLACK,
                              backColor=PALE, borderColor=YELLOW, borderWidth=1, borderPadding=9,
                              fontSize=9.5, leading=14, spaceBefore=6, spaceAfter=10))
    styles.add(ParagraphStyle(name="BeeSmall", parent=styles["BodyText"], textColor=GRAY,
                              fontSize=9.2, leading=14, spaceAfter=9))

    doc = SimpleDocTemplate(str(REPORT), pagesize=A4, rightMargin=1.65 * cm, leftMargin=1.65 * cm,
                            topMargin=1.35 * cm, bottomMargin=1.35 * cm,
                            title="Heart Sound Classification Project - Mourad Mohamed Gad",
                            author="Mourad Mohamed Gad")

    base = model_metrics["test"]
    final = selective["test"]
    story = [
        Spacer(1, 0.8 * cm),
        Paragraph("Heart Sound Classification from Digital Stethoscope Recordings", styles["BeeTitle"]),
        Paragraph("Prepared by Mourad Mohamed Gad", styles["BeeName"]),
        Paragraph("Project report - August 2026", styles["BeeSubtitle"]),
        Spacer(1, 0.35 * cm),
        Paragraph("Project overview", styles["BeeH1"]),
        Paragraph("This project uses recorded heart sounds to classify a recording as normal or abnormal. When the model is not confident enough, it returns an uncertain result instead of forcing a prediction.", styles["BeeBody"]),
        Paragraph("Main test results", styles["BeeH2"]),
        metric_table([
            ["Result type", "Precision", "Recall", "Specificity", "Coverage"],
            ["Binary result", pct(base["precision"]), pct(base["recall_sensitivity"]), pct(base["specificity"]), "100.0%"],
            ["Final three-way result", pct(final["precision"]), pct(final["recall_sensitivity"]), pct(final["specificity"]), pct(final["coverage"])],
        ], [4.2 * cm, 2.5 * cm, 2.5 * cm, 2.8 * cm, 2.5 * cm]),
        Paragraph("Why two result types are shown", styles["BeeH2"]),
        metric_table([
            ["Result type", "What it means"],
            [Paragraph("<b>Binary result</b>", styles["BeeSmall"]),
             Paragraph("The model must choose normal or abnormal for every recording. This is useful for comparing the model with a standard two-class test, but it can force a choice on difficult recordings.", styles["BeeSmall"])],
            [Paragraph("<b>Final three-way result</b>", styles["BeeSmall"]),
             Paragraph("The model can answer likely normal, abnormal, or uncertain. The uncertain result is used when the probability is between the two confidence limits. This is the version used by the application.", styles["BeeSmall"])],
        ], [4.0 * cm, 11.5 * cm]),
        Spacer(1, 0.3 * cm),
        Paragraph(f"The final result is calculated only for recordings that received a clear normal or abnormal prediction. The model gave a clear answer for {pct(final['coverage'])} of the test recordings. The other {pct(1 - final['coverage'])} were marked uncertain.", styles["BeeNote"]),
        Image(str(CHARTS / "class_distribution.png"), width=15.5 * cm, height=7.9 * cm),
        PageBreak(),
        Paragraph("The dataset", styles["BeeH1"]),
        Paragraph("The project uses the public PhysioNet/Computing in Cardiology Challenge 2016 heart sound dataset. The recordings were collected by several research groups in clinical and non-clinical environments. They include both children and adults and contain real recording noise such as breathing, speech, movement, and stethoscope contact noise.", styles["BeeBody"]),
        Paragraph("Where the data came from", styles["BeeH2"]),
        Paragraph("Dataset page: https://physionet.org/content/challenge-2016/1.0.0/<br/>Dataset license: Open Data Commons Attribution License v1.0<br/>Downloaded file used in this project: training.zip", styles["BeeNote"]),
        Paragraph("Data used", styles["BeeH2"]),
        metric_table([
            ["Item", "Value"], ["Total labeled recordings", "3,240"],
            ["Normal recordings", "2,575 (79.5%)"], ["Abnormal recordings", "665 (20.5%)"],
            ["Source databases", "6"], ["Audio format", "WAV"],
            ["Standard sample rate", "2,000 Hz"], ["Training / validation / test", "70% / 15% / 15%"],
        ], [7.0 * cm, 8.5 * cm]),
        Spacer(1, 0.25 * cm),
        Paragraph("What the labels mean", styles["BeeH2"]),
        Paragraph("Normal means that the recording was labeled as a normal heart sound. Abnormal means that the patient had a confirmed cardiac abnormality. The dataset does not provide a separate disease name for every recording, so this project predicts normal or abnormal rather than a specific disease.", styles["BeeBody"]),
        Paragraph("How the recordings were prepared", styles["BeeH2"]),
        Paragraph("Each WAV file was converted to one audio channel and resampled to 2,000 Hz. A 20-800 Hz filter was applied to keep the main heart-sound frequency range. The audio level was normalized. The program then calculated MFCC, spectral, energy, timing, frequency-band, and wavelet features from each recording.", styles["BeeBody"]),
        Paragraph("All 3,240 recordings were processed successfully. The abnormal class was smaller, so class balancing was used during training.", styles["BeeBody"]),
        PageBreak(),
        Paragraph("What the heart-sound data looks like", styles["BeeH1"]),
        Paragraph("The figure below shows two real recordings from the held-out test set. Only the first five seconds are displayed so the sound pattern is easy to see.", styles["BeeBody"]),
        Image(str(CHARTS / "recording_examples.png"), width=16.2 * cm, height=9.5 * cm),
        Paragraph("Waveform", styles["BeeH2"]),
        Paragraph("The waveform shows how the recorded sound pressure changes with time. Repeating peaks usually follow the heart cycles. The waveform can also contain noise from breathing, movement, or stethoscope contact.", styles["BeeBody"]),
        Paragraph("Spectrogram", styles["BeeH2"]),
        Paragraph("The spectrogram shows the same recording using time on the horizontal axis and frequency on the vertical axis. Brighter areas contain more sound energy. This view helps show when sound energy appears and which frequencies contain it.", styles["BeeBody"]),
        Paragraph("These plots are examples only. A waveform or spectrogram should not be diagnosed by visual appearance alone.", styles["BeeNote"]),
        PageBreak(),
        Paragraph("How the detection looked", styles["BeeH1"]),
        Paragraph("The model converts the features from each recording into an abnormality probability. The two fixed limits then convert that probability into likely normal, uncertain, or abnormal.", styles["BeeBody"]),
        Image(str(CHARTS / "detection_examples.png"), width=16.2 * cm, height=5.2 * cm),
        metric_table([
            ["Record", "Reference label", "Abnormality probability", "Final output"],
            ["e01432", "Normal", "0.003", "Likely normal"],
            ["a0287", "Normal", "0.252", "Uncertain"],
            ["e01623", "Abnormal", "0.977", "Abnormal"],
        ], [3.2 * cm, 3.8 * cm, 4.5 * cm, 4.0 * cm]),
        Spacer(1, 0.3 * cm),
        Paragraph("Example 1: clear normal", styles["BeeH2"]),
        Paragraph("Record e01432 received probability 0.003, which is below the normal limit of 0.215. The final output was likely normal.", styles["BeeBody"]),
        Paragraph("Example 2: uncertain", styles["BeeH2"]),
        Paragraph("Record a0287 received probability 0.252. This is above 0.215 but below 0.825, so the model did not force a normal or abnormal answer. The final output was uncertain.", styles["BeeBody"]),
        Paragraph("Example 3: clear abnormal", styles["BeeH2"]),
        Paragraph("Record e01623 received probability 0.977, which is above the abnormal limit of 0.825. The final output was abnormal.", styles["BeeBody"]),
        Paragraph("The reference label is the dataset label. The final output is the result produced by the trained model.", styles["BeeNote"]),
        PageBreak(),
        Paragraph("The model and results", styles["BeeH1"]),
        Paragraph("The final CPU model combines Extra Trees and LightGBM. Both are fast models for structured numerical features. The model produces a probability between 0 and 1, where a larger value means that an abnormal recording is more likely.", styles["BeeBody"]),
        Paragraph("Binary test results", styles["BeeH2"]),
        metric_table([
            ["Metric", "Result"], ["Accuracy", pct(base["accuracy"])],
            ["Balanced accuracy", pct(base["balanced_accuracy"])], ["Precision", pct(base["precision"])],
            ["Recall", pct(base["recall_sensitivity"])], ["Specificity", pct(base["specificity"])],
            ["F1 score", pct(base["f1"])], ["AUROC", f"{base['roc_auc']:.3f}"],
            ["Average precision", f"{base['average_precision']:.3f}"],
        ], [8.0 * cm, 4.0 * cm]),
        Spacer(1, 0.25 * cm),
        Paragraph("The binary model detected most abnormal recordings, but some normal recordings were also predicted as abnormal. For this reason, the final version uses an uncertain range.", styles["BeeBody"]),
        Image(str(CHARTS / "roc_pr.png"), width=16.0 * cm, height=6.2 * cm),
        PageBreak(),
        Paragraph("Final three-way results", styles["BeeH1"]),
        Paragraph("The final decision rules were fixed using the validation set. A probability at or below 0.215 is reported as likely normal. A probability at or above 0.825 is reported as abnormal. Values between these limits are reported as uncertain.", styles["BeeBody"]),
        Image(str(CHARTS / "confusion.png"), width=11.5 * cm, height=8.4 * cm),
        metric_table([
            ["Measure", "Test result"],
            ["Clear predictions", f"{final['accepted_n']} of {final['accepted_n'] + final['uncertain_count']}"],
            ["Coverage", pct(final["coverage"])], ["Precision", pct(final["precision"])],
            ["Recall", pct(final["recall_sensitivity"])], ["Specificity", pct(final["specificity"])],
            ["Referral sensitivity", pct(final["referral_sensitivity"])],
        ], [8.0 * cm, 4.0 * cm]),
        Spacer(1, 0.25 * cm),
        Paragraph("Among the clear test predictions, 343 normal and 35 abnormal recordings were classified correctly. There were three false positives and one false negative. A further 104 recordings were marked uncertain.", styles["BeeBody"]),
        Paragraph("These results describe this dataset and test split only. The project is a research demonstration and is not a medical diagnosis tool. Patient identifiers are not available consistently across all six sources, so the evaluation is performed at recording level.", styles["BeeNote"]),
        PageBreak(),
        Paragraph("References", styles["BeeH1"]),
        Paragraph("1. Liu C, Springer D, Li Q, et al. An open access database for the evaluation of heart sound algorithms. Physiological Measurement. 2016;37(12):2181-2213. https://doi.org/10.1088/0967-3334/37/12/2181", styles["BeeSmall"]),
        Paragraph("2. Clifford GD, Liu C, Moody B, et al. Classification of normal/abnormal heart sound recordings: the PhysioNet/Computing in Cardiology Challenge 2016. Computing in Cardiology. 2016.", styles["BeeSmall"]),
        Paragraph("3. PhysioNet. Classification of Heart Sound Recordings, version 1.0.0. https://physionet.org/content/challenge-2016/1.0.0/", styles["BeeSmall"]),
    ]

    doc.build(story, onFirstPage=page_decoration, onLaterPages=page_decoration)
    print(REPORT)


if __name__ == "__main__":
    main()
