from __future__ import annotations

import json
import sys
from pathlib import Path

import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.platypus import Image, PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle
from sklearn.metrics import ConfusionMatrixDisplay, precision_recall_curve, roc_curve

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from scripts.train import split_indices

MODEL_DIR = ROOT / "outputs" / "model_final"
REPORT = ROOT / "outputs" / "CardioScreen_Project_Report.pdf"
CHARTS = ROOT / "work" / "report_charts_bee"
CHARTS.mkdir(parents=True, exist_ok=True)

BLACK = colors.HexColor("#171717")
YELLOW = colors.HexColor("#F4C430")
PALE = colors.HexColor("#FFF6CF")
GRAY = colors.HexColor("#5C5C5C")
WHITE = colors.white


def probability(artifact, frame):
    weighted = sum(artifact["weights"][name] * model.predict_proba(frame)[:, 1]
                   for name, model in artifact["models"].items())
    return weighted / sum(artifact["weights"].values())


def make_charts(df, y_test, probabilities, selective):
    plt.style.use("seaborn-v0_8-whitegrid")
    fig, ax = plt.subplots(figsize=(7.2, 3.7))
    counts = df["label"].value_counts().sort_index()
    ax.bar(["Normal", "Abnormal"], counts.values, color=["#171717", "#F4C430"])
    for i, value in enumerate(counts.values):
        ax.text(i, value + 35, f"{value:,}", ha="center", weight="bold")
    ax.set_ylabel("Number of recordings")
    ax.set_title("Dataset class distribution")
    ax.set_ylim(0, max(counts.values) * 1.14)
    fig.tight_layout()
    fig.savefig(CHARTS / "class_distribution.png", dpi=180)
    plt.close(fig)

    fpr, tpr, _ = roc_curve(y_test, probabilities)
    precision, recall, _ = precision_recall_curve(y_test, probabilities)
    fig, axes = plt.subplots(1, 2, figsize=(9.4, 3.6))
    axes[0].plot(fpr, tpr, color="#171717", lw=2.4)
    axes[0].plot([0, 1], [0, 1], "--", color="#A0A0A0")
    axes[0].set(xlabel="False-positive rate", ylabel="True-positive rate", title="ROC curve")
    axes[1].plot(recall, precision, color="#E0AA00", lw=2.4)
    axes[1].set(xlabel="Recall", ylabel="Precision", title="Precision-recall curve", ylim=(0, 1.02))
    fig.tight_layout()
    fig.savefig(CHARTS / "roc_pr.png", dpi=180)
    plt.close(fig)

    low = selective["validation"]["low_threshold"]
    high = selective["validation"]["high_threshold"]
    accepted = (probabilities <= low) | (probabilities >= high)
    fig, ax = plt.subplots(figsize=(5.2, 3.9))
    ConfusionMatrixDisplay.from_predictions(
        y_test[accepted], probabilities[accepted] >= high,
        display_labels=["Normal", "Abnormal"], colorbar=False, cmap="YlOrBr", ax=ax
    )
    ax.set_title("Final test confusion matrix")
    fig.tight_layout()
    fig.savefig(CHARTS / "confusion.png", dpi=180)
    plt.close(fig)


def page_decoration(canvas, doc):
    canvas.saveState()
    width, height = A4
    canvas.setFillColor(BLACK)
    canvas.rect(0, height - 0.42 * cm, width, 0.42 * cm, fill=1, stroke=0)
    canvas.setFillColor(YELLOW)
    canvas.rect(0, height - 0.50 * cm, width, 0.08 * cm, fill=1, stroke=0)
    canvas.setFont("Helvetica", 8)
    canvas.setFillColor(GRAY)
    canvas.drawString(1.7 * cm, 0.72 * cm, "Heart Sound Classification Project")
    canvas.drawRightString(width - 1.7 * cm, 0.72 * cm, f"Page {doc.page}")
    canvas.restoreState()


def metric_table(rows, widths):
    table = Table(rows, colWidths=widths)
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), BLACK),
        ("TEXTCOLOR", (0, 0), (-1, 0), YELLOW),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [WHITE, PALE]),
        ("GRID", (0, 0), (-1, -1), 0.45, colors.HexColor("#B8A45A")),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ]))
    return table


def pct(value):
    return f"{100 * value:.1f}%"


def main():
    model_metrics = json.loads((MODEL_DIR / "metrics.json").read_text())
    selective = json.loads((MODEL_DIR / "selective_metrics.json").read_text())
    artifact = joblib.load(MODEL_DIR / "heart_sound_model.joblib")
    df = pd.read_csv(ROOT / "work" / "features_v2.csv")
    metadata = ["record", "path", "label", "source"]
    feature_names = [column for column in df.columns if column not in metadata]
    X = df[feature_names].replace([np.inf, -np.inf], np.nan)
    y = df["label"].astype(int).to_numpy()
    _, _, test_idx = split_indices(df)
    test_probability = probability(artifact, X.iloc[test_idx])
    make_charts(df, y[test_idx], test_probability, selective)

    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name="BeeTitle", parent=styles["Title"], textColor=BLACK,
                              fontName="Helvetica-Bold", fontSize=24, leading=29, spaceAfter=10))
    styles.add(ParagraphStyle(name="BeeSubtitle", parent=styles["BodyText"], textColor=GRAY,
                              fontSize=11.5, leading=16, spaceAfter=7))
    styles.add(ParagraphStyle(name="BeeName", parent=styles["BodyText"], textColor=BLACK,
                              fontName="Helvetica-Bold", fontSize=12, leading=16, spaceAfter=5))
    styles.add(ParagraphStyle(name="BeeH1", parent=styles["Heading1"], textColor=BLACK,
                              backColor=YELLOW, borderPadding=7, fontSize=16, leading=20,
                              spaceBefore=10, spaceAfter=9))
    styles.add(ParagraphStyle(name="BeeH2", parent=styles["Heading2"], textColor=BLACK,
                              fontSize=12.5, leading=16, spaceBefore=8, spaceAfter=5))
    styles.add(ParagraphStyle(name="BeeBody", parent=styles["BodyText"], textColor=BLACK,
                              fontSize=9.7, leading=14, spaceAfter=7))
    styles.add(ParagraphStyle(name="BeeNote", parent=styles["BodyText"], textColor=BLACK,
                              backColor=PALE, borderColor=YELLOW, borderWidth=1, borderPadding=9,
                              fontSize=9.5, leading=14, spaceBefore=6, spaceAfter=10))
    styles.add(ParagraphStyle(name="BeeSmall", parent=styles["BodyText"], textColor=GRAY,
                              fontSize=9.2, leading=14, spaceAfter=9))

    doc = SimpleDocTemplate(str(REPORT), pagesize=A4, rightMargin=1.65 * cm, leftMargin=1.65 * cm,
                            topMargin=1.35 * cm, bottomMargin=1.35 * cm,
                            title="Heart Sound Classification Project - Mourad Mohamed Gad",
                            author="Mourad Mohamed Gad")

    base = model_metrics["test"]
    final = selective["test"]
    story = [
        Spacer(1, 0.8 * cm),
        Paragraph("Heart Sound Classification from Digital Stethoscope Recordings", styles["BeeTitle"]),
        Paragraph("Prepared by Mourad Mohamed Gad", styles["BeeName"]),
        Paragraph("Project report - August 2026", styles["BeeSubtitle"]),
        Spacer(1, 0.35 * cm),
        Paragraph("Project overview", styles["BeeH1"]),
        Paragraph("This project uses recorded heart sounds to classify a recording as normal or abnormal. When the model is not confident enough, it returns an uncertain result instead of forcing a prediction.", styles["BeeBody"]),
        Paragraph("Main test results", styles["BeeH2"]),
        metric_table([
            ["Result type", "Precision", "Recall", "Specificity", "Coverage"],
            ["Binary result", pct(base["precision"]), pct(base["recall_sensitivity"]), pct(base["specificity"]), "100.0%"],
            ["Final three-way result", pct(final["precision"]), pct(final["recall_sensitivity"]), pct(final["specificity"]), pct(final["coverage"])],
        ], [4.2 * cm, 2.5 * cm, 2.5 * cm, 2.8 * cm, 2.5 * cm]),
        Spacer(1, 0.3 * cm),
        Paragraph(f"The final result is calculated only for recordings that received a clear normal or abnormal prediction. The model gave a clear answer for {pct(final['coverage'])} of the test recordings. The other {pct(1 - final['coverage'])} were marked uncertain.", styles["BeeNote"]),
        Image(str(CHARTS / "class_distribution.png"), width=15.5 * cm, height=7.9 * cm),
        PageBreak(),
        Paragraph("The dataset", styles["BeeH1"]),
        Paragraph("The project uses the public PhysioNet/Computing in Cardiology Challenge 2016 heart sound dataset. The recordings were collected by several research groups in clinical and non-clinical environments. They include both children and adults and contain real recording noise such as breathing, speech, movement, and stethoscope contact noise.", styles["BeeBody"]),
        Paragraph("Where the data came from", styles["BeeH2"]),
        Paragraph("Dataset page: https://physionet.org/content/challenge-2016/1.0.0/<br/>Dataset license: Open Data Commons Attribution License v1.0<br/>Downloaded file used in this project: training.zip", styles["BeeNote"]),
        Paragraph("Data used", styles["BeeH2"]),
        metric_table([
            ["Item", "Value"], ["Total labeled recordings", "3,240"],
            ["Normal recordings", "2,575 (79.5%)"], ["Abnormal recordings", "665 (20.5%)"],
            ["Source databases", "6"], ["Audio format", "WAV"],
            ["Standard sample rate", "2,000 Hz"], ["Training / validation / test", "70% / 15% / 15%"],
        ], [7.0 * cm, 8.5 * cm]),
        Spacer(1, 0.25 * cm),
        Paragraph("What the labels mean", styles["BeeH2"]),
        Paragraph("Normal means that the recording was labeled as a normal heart sound. Abnormal means that the patient had a confirmed cardiac abnormality. The dataset does not provide a separate disease name for every recording, so this project predicts normal or abnormal rather than a specific disease.", styles["BeeBody"]),
        Paragraph("How the recordings were prepared", styles["BeeH2"]),
        Paragraph("Each WAV file was converted to one audio channel and resampled to 2,000 Hz. A 20-800 Hz filter was applied to keep the main heart-sound frequency range. The audio level was normalized. The program then calculated MFCC, spectral, energy, timing, frequency-band, and wavelet features from each recording.", styles["BeeBody"]),
        Paragraph("All 3,240 recordings were processed successfully. The abnormal class was smaller, so class balancing was used during training.", styles["BeeBody"]),
        PageBreak(),
        Paragraph("The model and results", styles["BeeH1"]),
        Paragraph("The final CPU model combines Extra Trees and LightGBM. Both are fast models for structured numerical features. The model produces a probability between 0 and 1, where a larger value means that an abnormal recording is more likely.", styles["BeeBody"]),
        Paragraph("Binary test results", styles["BeeH2"]),
        metric_table([
            ["Metric", "Result"], ["Accuracy", pct(base["accuracy"])],
            ["Balanced accuracy", pct(base["balanced_accuracy"])], ["Precision", pct(base["precision"])],
            ["Recall", pct(base["recall_sensitivity"])], ["Specificity", pct(base["specificity"])],
            ["F1 score", pct(base["f1"])], ["AUROC", f"{base['roc_auc']:.3f}"],
            ["Average precision", f"{base['average_precision']:.3f}"],
        ], [8.0 * cm, 4.0 * cm]),
        Spacer(1, 0.25 * cm),
        Paragraph("The binary model detected most abnormal recordings, but some normal recordings were also predicted as abnormal. For this reason, the final version uses an uncertain range.", styles["BeeBody"]),
        Image(str(CHARTS / "roc_pr.png"), width=16.0 * cm, height=6.2 * cm),
        PageBreak(),
        Paragraph("Final three-way results", styles["BeeH1"]),
        Paragraph("The final decision rules were fixed using the validation set. A probability at or below 0.215 is reported as likely normal. A probability at or above 0.825 is reported as abnormal. Values between these limits are reported as uncertain.", styles["BeeBody"]),
        Image(str(CHARTS / "confusion.png"), width=11.5 * cm, height=8.4 * cm),
        metric_table([
            ["Measure", "Test result"],
            ["Clear predictions", f"{final['accepted_n']} of {final['accepted_n'] + final['uncertain_count']}"],
            ["Coverage", pct(final["coverage"])], ["Precision", pct(final["precision"])],
            ["Recall", pct(final["recall_sensitivity"])], ["Specificity", pct(final["specificity"])],
            ["Referral sensitivity", pct(final["referral_sensitivity"])],
        ], [8.0 * cm, 4.0 * cm]),
        Spacer(1, 0.25 * cm),
        Paragraph("Among the clear test predictions, 343 normal and 35 abnormal recordings were classified correctly. There were three false positives and one false negative. A further 104 recordings were marked uncertain.", styles["BeeBody"]),
        Paragraph("These results describe this dataset and test split only. The project is a research demonstration and is not a medical diagnosis tool. Patient identifiers are not available consistently across all six sources, so the evaluation is performed at recording level.", styles["BeeNote"]),
        PageBreak(),
        Paragraph("References", styles["BeeH1"]),
        Paragraph("1. Liu C, Springer D, Li Q, et al. An open access database for the evaluation of heart sound algorithms. Physiological Measurement. 2016;37(12):2181-2213. https://doi.org/10.1088/0967-3334/37/12/2181", styles["BeeSmall"]),
        Paragraph("2. Clifford GD, Liu C, Moody B, et al. Classification of normal/abnormal heart sound recordings: the PhysioNet/Computing in Cardiology Challenge 2016. Computing in Cardiology. 2016.", styles["BeeSmall"]),
        Paragraph("3. PhysioNet. Classification of Heart Sound Recordings, version 1.0.0. https://physionet.org/content/challenge-2016/1.0.0/", styles["BeeSmall"]),
    ]

    doc.build(story, onFirstPage=page_decoration, onLaterPages=page_decoration)
    print(REPORT)


if __name__ == "__main__":
    main()
